## BASE PROGRAMMING LANGUAGE
### Please run with python 3.10 version
```
$ ./basec.py input.txt 
```
